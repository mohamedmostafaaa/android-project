package com.example.shehbashahab.whatsfordinner;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.shehbashahab.whatsfordinner.adapters.GroceriesArrayAdapter;
import com.example.shehbashahab.whatsfordinner.models.Grocery;
import com.example.shehbashahab.whatsfordinner.utils.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class ToBuyList extends AppCompatActivity {
    ListView toDoList ;
    private GroceriesArrayAdapter aGroceries;
    ArrayAdapter<String> adapter ;
    private List<Grocery> groceries;
    private DatabaseHelper helper;

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPostResume() {
        super.onPostResume();

    }

    @Override
    protected void onPause() {

        Grocery g;
        String x;
        ArrayList<Grocery> glist = new ArrayList<Grocery>();
        for (int i = 0 ; i< adapter.getCount();i++)
        {
            x = adapter.getItem(i);
            g = helper.getGroceriesByName(x);
            glist.add(g);
        }
        helper.newGroceriesList(glist);

        super.onPause();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_buy_list);

        helper = DatabaseHelper.getInstance(this);
        groceries = helper.getAllGroceries();

        toDoList = (ListView) findViewById(R.id.A3_toDoListItem);
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
        for(int j =0 ; j<groceries.size();j++)
        {
            if(groceries.get(j).count != -1)
            adapter.add(groceries.get(j).getName());
        }

        toDoList.setAdapter(adapter);



        toDoList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Get the selected item text from ListView
                String selectedItem = (String) parent.getItemAtPosition(position);

                // Display the selected item text on TextView
                Toast.makeText(getApplicationContext(),selectedItem, Toast.LENGTH_SHORT).show();
            }
        });

        toDoList.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> parent, View v, int position, long id) {
                String toBeRemoved = (String)parent.getItemAtPosition(position);
                Grocery g = helper.getGroceriesByName(toBeRemoved);
                helper.updateGroceryCount(g,-1);
                adapter.remove(toBeRemoved);
                return true;
            }
        });
    }

}
