package com.example.shehbashahab.whatsfordinner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.shehbashahab.whatsfordinner.models.MealPlan;
import com.example.shehbashahab.whatsfordinner.utils.DatabaseHelper;

import org.w3c.dom.Text;

public class ViewDayMeals extends AppCompatActivity {
    private DatabaseHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_day_meals);
        TextView t_breakfast ;
        TextView t_lunch ;
        TextView t_dinner ;

        t_breakfast = findViewById(R.id.finalBreakfast);
        t_lunch = findViewById(R.id.finalLunch);
        t_dinner = findViewById(R.id.finalDinner);
        Intent mIntent = getIntent();
        int day = mIntent.getIntExtra("day", 0);
        setDayOfWeekLabel(day);

        try
        {
            helper = DatabaseHelper.getInstance(this);
            MealPlan m = helper.getMealPlanByDay(day);



            if(m.getBreakfast() != null)
                t_breakfast.setText(m.getBreakfast().toString());

            if(m.getDinner() != null)
                t_dinner.setText(m.getDinner().toString());

            if(m.getLunch() != null)
                t_lunch.setText(m.getLunch().toString());
        }
        catch (Exception e)
        {
            t_breakfast.setText("Add");
            t_dinner.setText("Add");
            t_lunch.setText("Add");
        }



  }

    private void setDayOfWeekLabel(int x) {
        String label = "";
        switch (x) {
            case 1:
                label = "Monday";
                break;
            case 2:
                label = "Tuesday";
                break;
            case 3:
                label = "Wednesday";
                break;
            case 4:
                label = "Thursday";
                break;
            case 5:
                label = "Friday";
                break;
            case 6:
                label = "Saturday";
                break;
            case 7:
                label = "Sunday";
                break;
        }
        TextView dayOfWeek = findViewById(R.id.ViewDayOfWeek);
        dayOfWeek.setText(label);
    }
}
