package com.example.shehbashahab.whatsfordinner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ViewMealsForDay extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_meals_for_day);

        Button btn;
        btn = findViewById(R.id.ViewbtnMonday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewMealsForDay.this, ViewDayMeals.class);
                i.putExtra("day", 1);
                startActivity(i);
            }
        });

        btn = findViewById(R.id.ViewbtnTuesday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewMealsForDay.this, ViewDayMeals.class);

                i.putExtra("day", 2);
                startActivity(i);
            }
        });

        btn = findViewById(R.id.ViewbtnWednesday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewMealsForDay.this, ViewDayMeals.class);

                i.putExtra("day", 3);
                startActivity(i);
            }
        });

        btn = findViewById(R.id.ViewbtnThursday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewMealsForDay.this, ViewDayMeals.class);

                i.putExtra("day", 4);
                startActivity(i);
            }
        });

        btn = findViewById(R.id.ViewbtnFriday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewMealsForDay.this, ViewDayMeals.class);

                i.putExtra("day", 5);
                startActivity(i);
            }
        });


        btn = findViewById(R.id.ViewbtnSaturday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewMealsForDay.this, ViewDayMeals.class);

                i.putExtra("day", 6);
                startActivity(i);
            }
        });

        btn = findViewById(R.id.ViewbtnSunday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewMealsForDay.this, ViewDayMeals.class);

                i.putExtra("day", 7);
                startActivity(i);
            }
        });
    }
}
