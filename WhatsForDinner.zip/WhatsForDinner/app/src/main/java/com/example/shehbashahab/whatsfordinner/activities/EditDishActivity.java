package com.example.shehbashahab.whatsfordinner.activities;

import com.example.shehbashahab.whatsfordinner.R;
import com.example.shehbashahab.whatsfordinner.models.Recipe;
import com.example.shehbashahab.whatsfordinner.utils.DatabaseHelper;
import com.example.shehbashahab.whatsfordinner.utils.Utility;
import com.nobrain.android.permissions.AndroidPermissions;
import com.nobrain.android.permissions.Checker;
import com.nobrain.android.permissions.Result;
import com.squareup.picasso.Picasso;

import android.Manifest;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.Toast;

import java.io.File;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import fr.ganfra.materialspinner.MaterialSpinner;

public class EditDishActivity extends AppCompatActivity {

    private static final int REQUEST_CODE = 102;
    private static final int RESULT_LOAD_IMAGE = 1;

    @BindView(R.id.etRecipeName)
    EditText etName;
    @BindView(R.id.etRecipeCookingDirections)
    EditText etDirections;
    @BindView(R.id.etImageURLFromWeb)
    EditText etWebImageUrl;
    @BindView(R.id.ivRecipeImage)
    ImageView ivRecipeImage;
    @BindView(R.id.spIngredient1)
    MaterialSpinner spIngredient1;
    @BindView(R.id.spIngredient2)
    MaterialSpinner spIngredient2;
    @BindView(R.id.spIngredient3)
    MaterialSpinner spIngredient3;
    @BindView(R.id.spIngredient4)
    MaterialSpinner spIngredient4;
    @BindView(R.id.spIngredient5)
    MaterialSpinner spIngredient5;
    @BindView(R.id.spIngredient6)
    MaterialSpinner spIngredient6;
    @BindView(R.id.spIngredient7)
    MaterialSpinner spIngredient7;
    @BindView(R.id.spIngredient8)
    MaterialSpinner spIngredient8;
    @BindView(R.id.spIngredient9)
    MaterialSpinner spIngredient9;
    @BindView(R.id.spIngredient10)
    MaterialSpinner spIngredient10;

    @BindView(R.id.spinnerLayout)
    TableLayout spinnerLayout;

    Recipe recipe;
    private String picturePath;
    private DatabaseHelper helper;
    private ArrayAdapter<String> ingredientsAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_dish);

        ButterKnife.bind(this);
        helper = DatabaseHelper.getInstance(this);

        recipe = (Recipe) getIntent().getExtras().getSerializable("recipe");

        loadImage();
        loadIngredients();
        populateFields();

        etName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    validateRecipeName();
                }
            }
        });

        etWebImageUrl.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    picturePath = etWebImageUrl.getText().toString().trim();
                    Picasso.with(getApplicationContext()).load(picturePath).into(ivRecipeImage);
                    etWebImageUrl.setVisibility(View.GONE);
                }
            }
        });
    }

    private void loadImage() {
        String uri = recipe.getPicturePath();
        if (uri != null) {
            if (Utility.isLocalFile(uri)) {
                Picasso.with(getApplicationContext()).load(new File(uri)).into(ivRecipeImage);
            } else {
                Picasso.with(getApplicationContext()).load(uri).into(ivRecipeImage);
            }
        }
    }

    protected void addFromWeb(View view) {
        etWebImageUrl.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Update ingredient spinners
        ingredientsAdapter.clear();
        ingredientsAdapter.addAll(helper.getAllIngredientLabels());
        ingredientsAdapter.notifyDataSetChanged();
    }

    // TODO: Short on time. Need to tidy this logic.
    private void populateFields() {
        etName.setText(recipe.getName());
        etDirections.setText(recipe.getDirections());
        String ingredients = recipe.getIngredients();
        String[] ingredientArray = ingredients.split(",");
        int numIngredients = ingredientArray.length;

        // position +1 because MaterialSpinner uses [0] as hint
        if (0 < numIngredients)
            spIngredient1.setSelection(ingredientsAdapter.getPosition(ingredientArray[0]) + 1);
        if (1 < numIngredients)
            spIngredient2.setSelection(ingredientsAdapter.getPosition(ingredientArray[1]) + 1);
        if (2 < numIngredients)
            spIngredient3.setSelection(ingredientsAdapter.getPosition(ingredientArray[2]) + 1);
        if (3 < numIngredients)
            spIngredient4.setSelection(ingredientsAdapter.getPosition(ingredientArray[3]) + 1);
        if (4 < numIngredients)
            spIngredient5.setSelection(ingredientsAdapter.getPosition(ingredientArray[4]) + 1);
        if (5 < numIngredients)
            spIngredient6.setSelection(ingredientsAdapter.getPosition(ingredientArray[5]) + 1);
        if (6 < numIngredients)
            spIngredient7.setSelection(ingredientsAdapter.getPosition(ingredientArray[6]) + 1);
        if (7 < numIngredients)
            spIngredient8.setSelection(ingredientsAdapter.getPosition(ingredientArray[7]) + 1);
        if (8 < numIngredients)
            spIngredient9.setSelection(ingredientsAdapter.getPosition(ingredientArray[8]) + 1);
        if (9 < numIngredients)
            spIngredient10.setSelection(ingredientsAdapter.getPosition(ingredientArray[9]) + 1);
    }

    private void validateRecipeName() {
        String enteredRecipeName = etName.getText().toString().trim();
        Recipe recipeMatchingEnteredRecipeName = helper.getRecipeByName(enteredRecipeName);
        if (recipeMatchingEnteredRecipeName != null && (!recipeMatchingEnteredRecipeName.getName().equals(recipe.getName()))) {
            etName.setError("Recipe Name Already Exists");
        }
    }

    protected void updateRecipe(View view) {

     /*   String recipeName = etName.getText().toString().trim();
        String cookingDirections = etDirections.getText().toString().trim();

        if (validateRequiredFields(recipeName, cookingDirections)) {

            String recipePhoto = picturePath; // could be null
            String ingredients = buildIngredientList();

            Recipe updatedRecipe = new Recipe(recipeName, cookingDirections, recipePhoto, ingredients);
            helper.updateRecipe(recipe, updatedRecipe);

            finish();
        }*/
    }

    protected void createNewIngredient(View view) {
        Intent i = new Intent(this, NewIngredientActivity.class);
        startActivity(i);
    }

    // TODO: Short on time. Need to tidy this logic.
    private String buildIngredientList() {

        StringBuilder ingredients = new StringBuilder();

        String ingredient1, ingredient2, ingredient3, ingredient4, ingredient5, ingredient6, ingredient7, ingredient8, ingredient9, ingredient10;

        if (spIngredient1.getSelectedItem() != null) {
            ingredient1 = spIngredient1.getSelectedItem().toString().trim();
            ingredients.append(ingredient1);
        }

        if (spIngredient2.getSelectedItem() != null) {
            ingredient2 = spIngredient2.getSelectedItem().toString().trim();
            ingredients.append(",").append(ingredient2);
        }

        if (spIngredient3.getSelectedItem() != null) {
            ingredient3 = spIngredient3.getSelectedItem().toString().trim();
            ingredients.append(",").append(ingredient3);
        }

        if (spIngredient4.getSelectedItem() != null) {
            ingredient4 = spIngredient4.getSelectedItem().toString().trim();
            ingredients.append(",").append(ingredient4);
        }

        if (spIngredient5.getSelectedItem() != null) {
            ingredient5 = spIngredient5.getSelectedItem().toString().trim();
            ingredients.append(",").append(ingredient5);
        }

        if (spIngredient6.getSelectedItem() != null) {
            ingredient6 = spIngredient6.getSelectedItem().toString().trim();
            ingredients.append(",").append(ingredient6);
        }

        if (spIngredient7.getSelectedItem() != null) {
            ingredient7 = spIngredient7.getSelectedItem().toString().trim();
            ingredients.append(",").append(ingredient7);
        }

        if (spIngredient8.getSelectedItem() != null) {
            ingredient8 = spIngredient8.getSelectedItem().toString().trim();
            ingredients.append(",").append(ingredient8);
        }

        if (spIngredient9.getSelectedItem() != null) {
            ingredient9 = spIngredient9.getSelectedItem().toString().trim();
            ingredients.append(",").append(ingredient9);
        }

        if (spIngredient10.getSelectedItem() != null) {
            ingredient10 = spIngredient10.getSelectedItem().toString().trim();
            ingredients.append(",").append(ingredient10);
        }

        return ingredients.toString();
    }


    private boolean validateRequiredFields(String recipeName, String cookingDirections) {
        boolean success = true;

        if (recipeName.matches("")) {
            etName.setError("Required");
            success = false;
        }

        if (cookingDirections.matches("")) {
            etDirections.setError("Required");
            success = false;
        }

        return success;
    }

    private void loadIngredients() {
        List<String> labels = helper.getAllIngredientLabels();
        ingredientsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        ingredientsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spIngredient1.setAdapter(ingredientsAdapter);
        spIngredient2.setAdapter(ingredientsAdapter);
        spIngredient3.setAdapter(ingredientsAdapter);
        spIngredient4.setAdapter(ingredientsAdapter);
        spIngredient5.setAdapter(ingredientsAdapter);
        spIngredient6.setAdapter(ingredientsAdapter);
        spIngredient7.setAdapter(ingredientsAdapter);
        spIngredient8.setAdapter(ingredientsAdapter);
        spIngredient9.setAdapter(ingredientsAdapter);
        spIngredient10.setAdapter(ingredientsAdapter);
    }

    protected void editRecipeImage(View view) {
        etWebImageUrl.setVisibility(View.GONE);
        showGalleryIfPermissionGranted();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
            Uri selectedImage = data.getData();
            String[] filePathColumn = {MediaStore.Images.Media.DATA};

            Cursor cursor = getContentResolver().query(selectedImage,
                    filePathColumn, null, null, null);
            assert cursor != null;
            cursor.moveToFirst();

            int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
            picturePath = cursor.getString(columnIndex);
            cursor.close();

            Picasso.with(getApplicationContext()).load(new File(picturePath)).into(ivRecipeImage);

        }
    }

    private void startGallery() {
        Intent i = new Intent(
                Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(i, RESULT_LOAD_IMAGE);
    }

    private void showGalleryIfPermissionGranted() {
        AndroidPermissions.check(this)
                .permissions(Manifest.permission.READ_EXTERNAL_STORAGE)
                .hasPermissions(new Checker.Action0() {
                    @Override
                    public void call(String[] permissions) {
                        startGallery();
                    }
                })
                .noPermissions(new Checker.Action1() {
                    @Override
                    public void call(String[] permissions) {
                        ActivityCompat.requestPermissions(EditDishActivity.this
                                , new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}
                                , REQUEST_CODE);
                    }
                })
                .check();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull final String[] permissions, @NonNull int[] grantResults) {
        AndroidPermissions.result(EditDishActivity.this)
                .addPermissions(REQUEST_CODE, Manifest.permission.READ_EXTERNAL_STORAGE)
                .putActions(REQUEST_CODE, new Result.Action0() {
                    @Override
                    public void call() {
                        startGallery();

                    }
                }, new Result.Action1() {
                    @Override
                    public void call(String[] hasPermissions, String[] noPermissions) {
                        String msg = "Request Fail : " + noPermissions[0];
                        Toast.makeText(EditDishActivity.this,
                                msg,
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .result(requestCode, permissions, grantResults);
    }

}