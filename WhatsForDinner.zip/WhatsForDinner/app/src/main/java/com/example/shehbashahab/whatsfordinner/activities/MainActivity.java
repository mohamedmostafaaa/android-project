package com.example.shehbashahab.whatsfordinner.activities;

import com.example.shehbashahab.whatsfordinner.R;
import com.example.shehbashahab.whatsfordinner.ToBuyList;
import com.example.shehbashahab.whatsfordinner.ViewMealsForDay;
import com.example.shehbashahab.whatsfordinner.models.Grocery;
import com.example.shehbashahab.whatsfordinner.utils.DatabaseHelper;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        MyTimerTask myTask = new MyTimerTask();
        Timer myTimer = new Timer();

        myTimer.schedule(myTask, 10000, 1500);




        Button btn = (Button) findViewById(R.id.button1);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, MealsActivity.class);
                startActivity(i);
            }
        });

        
        btn = (Button) findViewById(R.id.button1view);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ViewMealsForDay.class);
                startActivity(i);
            }
        });
        Button recbtn = findViewById(R.id.button2);
        recbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public  void onClick(View v){
                Intent i = new Intent(MainActivity.this, RecipesListActivity.class);
                startActivity(i);
            }
        });


        Button grocbtn = findViewById(R.id.button3);
        grocbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public  void onClick(View v){
                Intent i = new Intent(MainActivity.this, ToBuyList.class);
                startActivity(i);
            }
        });
        Button newdishbtn = findViewById(R.id.button4);
        newdishbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public  void onClick(View v){
                Intent i = new Intent(MainActivity.this, NewDishActivity.class);
                startActivity(i);
            }
        });

        ImageView imgFavorite = (ImageView) findViewById(R.id.imageView);
        imgFavorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                alertDialog.setMessage(generateAlertDialogMessage());
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }
    private String generateAlertDialogMessage() {

        return "Author:El Qobtan <3" +
                "\n" +
                "Version Number: 1" +
                "\n" +
                "Contact: Team@gmail.com";
    }


    class MyTimerTask extends TimerTask {
        @Override
        public void run() {

            //generateNotification(getApplicationContext(), "Hello");
             DatabaseHelper helper;
            helper = DatabaseHelper.getInstance(getApplicationContext());
            List<Grocery> gList = helper.getAllGroceries();
                for(int i=0;i< gList.size();i++ ){
                    if(gList.get(i).count != -1){
                        addNotification();
                        break;
                    }
                }
        }
    }



    private void addNotification() {
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this)
                        .setSmallIcon(R.mipmap.ic_meals)
                        .setContentTitle("Shopping List")
                        .setContentText("Don't forget to buy some ingredients");

        Uri gmm  = Uri.parse("geo:0,0?q=markets");

        Intent notificationIntent = new Intent(Intent.ACTION_VIEW, gmm);
        notificationIntent.setPackage("com.google.android.apps.maps");
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setContentIntent(contentIntent);

        // Add as notification
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(0, builder.build());
    }




}