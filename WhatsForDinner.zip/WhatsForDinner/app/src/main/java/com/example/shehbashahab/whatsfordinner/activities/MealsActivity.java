package com.example.shehbashahab.whatsfordinner.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.shehbashahab.whatsfordinner.R;
import com.example.shehbashahab.whatsfordinner.setMealsToDay;

public class MealsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meals);


    Button btn;
        btn = findViewById(R.id.btnMonday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MealsActivity.this, setMealsToDay.class);
                i.putExtra("day", 1);
                startActivity(i);
            }
        });

        btn = findViewById(R.id.btnTuesday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MealsActivity.this, setMealsToDay.class);
                i.putExtra("day", 2);
                startActivity(i);
            }
        });

        btn = findViewById(R.id.btnWednesday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MealsActivity.this, setMealsToDay.class);
                i.putExtra("day", 3);
                startActivity(i);
            }
        });

        btn = findViewById(R.id.btnThursday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MealsActivity.this, setMealsToDay.class);
                i.putExtra("day", 4);
                startActivity(i);
            }
        });

        btn = findViewById(R.id.btnFriday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MealsActivity.this, setMealsToDay.class);
                i.putExtra("day", 5);
                startActivity(i);
            }
        });


        btn = findViewById(R.id.btnSaturday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MealsActivity.this, setMealsToDay.class);
                i.putExtra("day", 6);
                startActivity(i);
            }
        });

        btn = findViewById(R.id.btnSunday);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MealsActivity.this, setMealsToDay.class);
                i.putExtra("day", 7);
                startActivity(i);
            }
        });


    }
}