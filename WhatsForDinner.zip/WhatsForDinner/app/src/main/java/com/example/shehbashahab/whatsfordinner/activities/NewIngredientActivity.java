package com.example.shehbashahab.whatsfordinner.activities;

import com.example.shehbashahab.whatsfordinner.R;
import com.example.shehbashahab.whatsfordinner.models.Grocery;
import com.example.shehbashahab.whatsfordinner.models.Ingredient;
import com.example.shehbashahab.whatsfordinner.utils.DatabaseHelper;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import butterknife.BindView;
import butterknife.ButterKnife;

public class NewIngredientActivity extends AppCompatActivity {


    @BindView(R.id.editTextIngredientName)
    EditText editTextIngredientName;
    @BindView(R.id.spinnerIngredientUnit)
    Spinner spinnerIngredientUnit;
    private DatabaseHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_ingredient);
        ButterKnife.bind(this);
        helper = DatabaseHelper.getInstance(this);

        editTextIngredientName.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                validateIngredientName();
            }
        });

        Button save = findViewById(R.id.btnsaVEE);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextIngredientName.getText().toString().trim();
                String unit = spinnerIngredientUnit.getSelectedItem().toString();

                if (name.matches("")) {
                    editTextIngredientName.setError("Required");
                } else {
                    Ingredient ingredient = new Ingredient(name, unit);
                    helper.addIngredient(ingredient);

                   Grocery grocery = new Grocery(name, unit, -1);
                   helper.addGrocery(grocery);

                    finish();
                }
            }
        });
    }

    private void validateIngredientName() {
        String recipeName = editTextIngredientName.getText().toString().trim();
        if (helper.getIngredientByName(recipeName) != null) {
            editTextIngredientName.setError("Ingredient Name Already Exists");
        }
    }


}
