package com.example.shehbashahab.whatsfordinner.activities;

import com.example.shehbashahab.whatsfordinner.R;
import com.example.shehbashahab.whatsfordinner.fragments.RecipeDetailFragment;
import com.example.shehbashahab.whatsfordinner.models.Recipe;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

public class RecipeDetailActivity extends AppCompatActivity {
    RecipeDetailFragment fragmentRecipeDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_detail);
        Recipe recipe = (Recipe) getIntent().getSerializableExtra("recipe");
        if (savedInstanceState == null) {
            fragmentRecipeDetail = new RecipeDetailFragment();
            fragmentRecipeDetail = RecipeDetailFragment.newInstance(recipe);
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.flDetailContainer, fragmentRecipeDetail);
            ft.commit();
        }
    }

}