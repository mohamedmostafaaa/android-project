package com.example.shehbashahab.whatsfordinner.activities;

import com.example.shehbashahab.whatsfordinner.R;
import com.example.shehbashahab.whatsfordinner.fragments.RecipeDetailFragment;
import com.example.shehbashahab.whatsfordinner.fragments.RecipesListFragment;
import com.example.shehbashahab.whatsfordinner.models.Recipe;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.widget.FrameLayout;

public class RecipesListActivity extends AppCompatActivity implements RecipesListFragment.OnListRecipeSelectedListener {

    private boolean isTwoPane = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipes_list);

        determinePaneLayout();
    }

    private void determinePaneLayout() {
        FrameLayout fragmentItemDetail = findViewById(R.id.flDetailContainer);
        if (fragmentItemDetail != null) {
            isTwoPane = true;
            RecipesListFragment fragmentRecipesList =
                    (RecipesListFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentItemsList);
            fragmentRecipesList.setActivateOnItemClick(true);
        }
    }

    // Handles the event when the fragment list item is selected
    @Override
    public void onItemSelected(Recipe recipe) {
        if (isTwoPane) {
            RecipeDetailFragment fragmentRecipe = RecipeDetailFragment.newInstance(recipe);
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.flDetailContainer, fragmentRecipe);
            ft.commit();
        } else {
            Intent i = new Intent(this, RecipeDetailActivity.class);
            i.putExtra("recipe", recipe);
            startActivity(i);
        }
    }
}