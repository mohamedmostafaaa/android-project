package com.example.shehbashahab.whatsfordinner.activities;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;
import com.example.shehbashahab.whatsfordinner.R;
import com.example.shehbashahab.whatsfordinner.adapters.GroceriesArrayAdapter;
import com.example.shehbashahab.whatsfordinner.models.Grocery;
import com.example.shehbashahab.whatsfordinner.utils.DatabaseHelper;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class ViewGroceriesActivity extends AppCompatActivity {

    @BindView(R.id.swipeContainer)
    SwipeRefreshLayout swipeContainer;
    @BindView(R.id.lvGroceries)
    SwipeMenuListView lvTweets;
    private GroceriesArrayAdapter aGroceries;
    private ArrayList<Grocery> groceries;
    private DatabaseHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_groceries);
        ButterKnife.bind(this);
        helper = DatabaseHelper.getInstance(this);

        swipeContainer.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                populateGroceries();
            }

        });

        swipeContainer.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light,
                android.R.color.holo_orange_light,
                android.R.color.holo_red_light);


        groceries = new ArrayList<>();
        aGroceries = new GroceriesArrayAdapter(this, groceries);
        lvTweets.setAdapter(aGroceries);
        populateGroceries();

        lvTweets.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {
                Grocery grocery = aGroceries.getItem(position);

                int newCount = 0;

                switch (index) {
                    case 0:
                        // plus

                        helper.updateGroceryCount(grocery, newCount);
                        break;
                    case 1: // minus

                        helper.updateGroceryCount(grocery, newCount);
                        break;
                }

                populateGroceries();
                // false : close the menu; true : not close the menu
                return false;
            }
        });

        SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {
                SwipeMenuItem addGrocery = new SwipeMenuItem(
                        getApplicationContext());
                addGrocery.setWidth(150);
                addGrocery.setTitle("+");
                addGrocery.setTitleSize(30);
                addGrocery.setTitleColor(Color.BLACK);
                menu.addMenuItem(addGrocery);

                SwipeMenuItem deleteGrocery = new SwipeMenuItem(
                        getApplicationContext());
                deleteGrocery.setWidth(150);
                deleteGrocery.setTitle("-");
                deleteGrocery.setTitleSize(30);
                deleteGrocery.setTitleColor(Color.BLACK);
                menu.addMenuItem(deleteGrocery);
            }
        };


        lvTweets.setMenuCreator(creator);
    }

    private void populateGroceries() {
        aGroceries.clear();
        groceries.clear();
        aGroceries.addAll(helper.getAllGroceries());
        aGroceries.notifyDataSetChanged();
        swipeContainer.setRefreshing(false);
    }
}
