package com.example.shehbashahab.whatsfordinner.adapters;

import com.example.shehbashahab.whatsfordinner.R;
import com.example.shehbashahab.whatsfordinner.models.Grocery;

import android.content.Context;
import android.graphics.Paint;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by shehba.shahab on 10/1/17.
 */

public class GroceriesArrayAdapter extends ArrayAdapter<Grocery> {

    ViewHolder holder;

    public GroceriesArrayAdapter(Context context, List<Grocery> groceries) {
        super(context, 0, groceries);
    }

    @NonNull
    @Override
    public View getView(int position, View view, @NonNull ViewGroup parent) {

        final Grocery grocery = getItem(position);

        if (view != null) {
            holder = (ViewHolder) view.getTag();
        } else {
            view = LayoutInflater.from(getContext()).inflate(R.layout.item_grocery, parent, false);
            holder = new ViewHolder(view);
            view.setTag(holder);
        }

        assert grocery != null;
        holder.tvGroceryName.setText(grocery.getName());
        holder.tvGroceryUnit.setText(grocery.getUnit());


        return view;
    }

    static final class ViewHolder {
        @BindView(R.id.tvGroceryName)
        TextView tvGroceryName;
        @BindView(R.id.tvGroceryUnit)
        TextView tvGroceryUnit;
        @BindView(R.id.tvGroceryCount)
        TextView tvGroceryCount;

        ViewHolder(View view) {
            ButterKnife.bind(this, view);
        }

    }
}