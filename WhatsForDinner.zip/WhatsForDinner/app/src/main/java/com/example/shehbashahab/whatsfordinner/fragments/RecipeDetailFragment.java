package com.example.shehbashahab.whatsfordinner.fragments;

import com.example.shehbashahab.whatsfordinner.R;
import com.example.shehbashahab.whatsfordinner.models.Recipe;
import com.example.shehbashahab.whatsfordinner.utils.Utility;
import com.squareup.picasso.Picasso;

import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;

import butterknife.BindView;
import butterknife.ButterKnife;

public class RecipeDetailFragment extends Fragment {

    @BindView(R.id.tvRecipeName)
    TextView tvRecipeName;
    @BindView(R.id.tvRecipeDirections)
    TextView tvRecipeDirections;
    @BindView(R.id.ivRecipeImage)
    ImageView ivRecipeImage;
    @BindView(R.id.tvIngredients)
    TextView tvIngredients;
    @BindView(R.id.tvRecepiesCarbohidrates)
    TextView carbs;
    @BindView(R.id.tvRecepiesFats)
    TextView fats;
    @BindView(R.id.tvRecepiesProteins)
    TextView proteins;
    @BindView(R.id.tvRecepiesEstimatedTotalCalories)
    TextView totalCalories;
    private Recipe recipe;

    public static RecipeDetailFragment newInstance(Recipe recipe) {
        RecipeDetailFragment fragmentDemo = new RecipeDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable("recipe", recipe);
        fragmentDemo.setArguments(args);
        return fragmentDemo;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        recipe = (Recipe) getArguments().getSerializable("recipe");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_recipe_detail,
                container, false);

        ButterKnife.bind(this, view);

        tvRecipeName.setText(recipe.getName());
        tvRecipeDirections.setText(recipe.getDirections());

        carbs.setText(recipe.getCarbs().toString());

        fats.setText(recipe.getFats().toString());

        proteins.setText(recipe.getProtiens().toString());

        totalCalories.setText(recipe.getCalories().toString());
        if (recipe.getPicturePath() != null)
            ivRecipeImage.setImageBitmap(BitmapFactory.decodeFile(recipe.getPicturePath()));


        if (recipe.getIngredients() != null) {
            tvIngredients.setText(recipe.getIngredients().replaceAll(",", "\n"));
        }

        loadImage();
        return view;
    }

    private void loadImage() {
        String uri = recipe.getPicturePath();
        if (uri != null) {
            if (Utility.isLocalFile(uri)) {
                Picasso.with(getContext()).load(new File(uri)).into(ivRecipeImage);
            } else {
                Picasso.with(getContext()).load(uri).into(ivRecipeImage);
            }
        }
    }

}
