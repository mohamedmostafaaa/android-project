package com.example.shehbashahab.whatsfordinner.fragments;

import com.example.shehbashahab.whatsfordinner.R;
import com.example.shehbashahab.whatsfordinner.activities.EditDishActivity;
import com.example.shehbashahab.whatsfordinner.adapters.RecipesArrayAdapter;
import com.example.shehbashahab.whatsfordinner.models.Recipe;
import com.example.shehbashahab.whatsfordinner.models.ScheduleableMeal;
import com.example.shehbashahab.whatsfordinner.utils.DatabaseHelper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;


public class RecipesListFragment extends Fragment {

    @BindView(R.id.lvItems)
    ListView lvRecipes;
    List<Recipe> recipes;
    DatabaseHelper helper;
    private OnListRecipeSelectedListener listener;
    private ArrayAdapter<Recipe> aRecipes;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        helper = DatabaseHelper.getInstance(this.getActivity());

        recipes = helper.getAllRecipes();
        aRecipes = new RecipesArrayAdapter(this.getActivity(), recipes);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_recipes_list,
                container, false);

        ButterKnife.bind(this, view);

        // Attach adapter to listview
        lvRecipes.setAdapter(aRecipes);
        lvRecipes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View item,
                                    int position, long rowId) {
                // Retrieve item based on position
                Recipe recipe = aRecipes.getItem(position);
                // Fire selected listener event with recipe
                listener.onItemSelected(recipe);

                addToScheduleableMeals(recipe);
            }
        });

        lvRecipes.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View item,
                                           int position, long id) {

                Recipe recipe = aRecipes.getItem(position);
                Intent i = new Intent(getActivity(), EditDishActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("recipe", recipe);
                i.putExtras(bundle);
                startActivity(i);

                return true;
            }
        });

        return view;
    }

    private void addToScheduleableMeals(Recipe recipe) {
        // If recipe has already been added - appends count
        int count = helper.countScheduleableMealsMatchingName(recipe.getName());
        String recipeName = recipe.getName();
        if (count > 0) {
            count = count + 1;
            recipeName = recipeName + " - " + count;
        }

        ScheduleableMeal meal = new ScheduleableMeal(recipe != null ? recipeName : null);
        helper.addScheduleableMeal(meal);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof OnListRecipeSelectedListener) {
            listener = (OnListRecipeSelectedListener) activity;
        } else {
            throw new ClassCastException(
                    activity.toString()
                            + " must implement RecipesListFragment.OnListRecipeSelectedListener");
        }
    }

    /**
     * Turns on activate-on-click mode. When this mode is on, list items will be
     * given the 'activated' state when touched.
     */
    public void setActivateOnItemClick(boolean activateOnItemClick) {
        // When setting CHOICE_MODE_SINGLE, ListView will automatically
        // give items the 'activated' state when touched.
        lvRecipes.setChoiceMode(
                activateOnItemClick ? ListView.CHOICE_MODE_SINGLE
                        : ListView.CHOICE_MODE_NONE);
    }

    @Override
    public void onResume() {

        super.onResume();
        aRecipes.clear();
        aRecipes.addAll(helper.getAllRecipes());
        aRecipes.notifyDataSetChanged();
    }

    public interface OnListRecipeSelectedListener {
        void onItemSelected(Recipe recipe);
    }
}
