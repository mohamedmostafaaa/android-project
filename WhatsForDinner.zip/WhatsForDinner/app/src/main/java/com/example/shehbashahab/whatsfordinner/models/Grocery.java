package com.example.shehbashahab.whatsfordinner.models;

/**
 * Created by shehba.shahab on 10/1/17.
 */

public class Grocery {

    private String name;
    private String unit;

    public int count;

    public Grocery(String name, String unit, int count) {
        this.name = name;
        this.unit = unit;
        this.count = count;

    }

    public String getName() {
        return name;
    }

    public String getUnit() {
        return unit;
    }


}
