package com.example.shehbashahab.whatsfordinner.models;

import java.io.Serializable;

/**
 * Created by shehba.shahab on 9/30/17.
 */

public class Recipe implements Serializable {

    private static final long serialVersionUID = -1213949467658913456L;
    private String name;
    private String directions;
    private String picturePath;
    private String ingredients;

    private  float carbs;
    private  float fats;
    private  float protiens;

    private float totalCalories;

    public Recipe(String name, String directions, String picturePath, String ingredients,float carbs, float fats, float protiens) {
        this.name = name;
        this.directions = directions;
        this.picturePath = picturePath;
        this.ingredients = ingredients;
        this.carbs= carbs;
        this.fats = fats;
        this.protiens = protiens;

        totalCalories = nutritioncalculation.calculateCarbohidrates(this.carbs) + nutritioncalculation.calculateFats(this.fats) + nutritioncalculation.calculateProtiens(this.protiens);
    }

    public Float getCalories(){
        return  totalCalories;
    }
    public String getName() {
        return name;
    }

    public String getDirections() {
        return directions;
    }

    public String getPicturePath() {
        return picturePath;
    }

    public String getIngredients() {
        return ingredients;
    }

    public Float getCarbs() {
        return carbs;
    }

    public Float getProtiens() {
        return protiens;
    }

    public Float getFats() {
        return fats;
    }
}
