package com.example.shehbashahab.whatsfordinner.models;

/**
 * Created by shehba.shahab on 10/6/17.
 */

public class ScheduleableMeal {
    private String name;

    public ScheduleableMeal(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
