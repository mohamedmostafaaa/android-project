package com.example.shehbashahab.whatsfordinner.models;

public class nutritioncalculation {
    nutritioncalculation(){ }

    public static float calculateFats(float fat)
    {
        float result = fat * 4;
        return result;
    }
    public static float calculateProtiens(float protien)
    {
        float result = protien*4 ;
        return result;
    }
    public static float calculateCarbohidrates(float carb)
    {
        float result = carb *8 ;
        return result;
    }
}
