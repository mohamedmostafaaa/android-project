package com.example.shehbashahab.whatsfordinner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.shehbashahab.whatsfordinner.models.MealPlan;
import com.example.shehbashahab.whatsfordinner.utils.DatabaseHelper;

import java.util.List;

import butterknife.BindView;
import fr.ganfra.materialspinner.MaterialSpinner;

public class setMealsToDay extends AppCompatActivity {

    private DatabaseHelper helper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_meals_to_day);

        Intent mIntent = getIntent();
        int day = mIntent.getIntExtra("day", 0);
        setDayOfWeekLabel(day);

         helper = DatabaseHelper.getInstance(this);
        MealPlan mealPlanForDay = helper.getMealPlanByDay(day);

        fillSpinners(mealPlanForDay,helper);

        Button btn = findViewById(R.id.editMealSave);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String breakfast = null;
                String lunch = null;
                String dinner = null;

                // Save mealplan and delete from scheduleable

                MaterialSpinner spBreakfast = findViewById(R.id.spinnerBreakfast);
                if (spBreakfast.getSelectedItem() != null)
                    breakfast = spBreakfast.getSelectedItem().toString();

                MaterialSpinner spLunch = findViewById(R.id.spinnerLunch);
                if (spLunch.getSelectedItem() != null)
                    lunch = spLunch.getSelectedItem().toString();

                MaterialSpinner spDinner = findViewById(R.id.spinnerDinner);
                if (spDinner.getSelectedItem() != null)
                    dinner = spDinner.getSelectedItem().toString();

                TextView t = findViewById(R.id.EditDayOfWeek);
                String d = t.getText().toString();
                int day = 0;
                switch (d) {
                    case "Monday":
                        day = 1;
                        break;
                    case "Tuesday":
                        day = 2;
                        break;
                    case "Wednesday":
                        day = 3;
                        break;
                    case "Thursday":
                        day = 4;
                        break;
                    case "Friday":
                        day = 5;
                        break;
                    case "Saturday":
                        day = 6;
                        break;
                    case "Sunday":
                        day = 7;
                        break;
                }
                MealPlan mealPlan = new MealPlan(day, breakfast, lunch, dinner);
                helper.addMealPlan(mealPlan);

                finish();
            }
        });

    }

    private void setDayOfWeekLabel(int x) {
        String label = "";
        switch (x) {
            case 1:
                label = "Monday";
                break;
            case 2:
                label = "Tuesday";
                break;
            case 3:
                label = "Wednesday";
                break;
            case 4:
                label = "Thursday";
                break;
            case 5:
                label = "Friday";
                break;
            case 6:
                label = "Saturday";
                break;
            case 7:
                label = "Sunday";
                break;
        }
        TextView dayOfWeek = findViewById(R.id.EditDayOfWeek);
        dayOfWeek.setText(label);
    }

    private void fillSpinners (MealPlan m , DatabaseHelper h)
    {
        MaterialSpinner bf = findViewById(R.id.spinnerBreakfast);
        MaterialSpinner lu = findViewById(R.id.spinnerLunch);
        MaterialSpinner din = findViewById(R.id.spinnerDinner);

        List<String> labels = h.getAllRecipesLabels();
        ArrayAdapter<String> mealsAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        mealsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        bf.setAdapter(mealsAdapter);
        lu.setAdapter(mealsAdapter);
        din.setAdapter(mealsAdapter);

    }
}
