package com.example.shehbashahab.whatsfordinner.utils;

import com.example.shehbashahab.whatsfordinner.models.Grocery;
import com.example.shehbashahab.whatsfordinner.models.Ingredient;
import com.example.shehbashahab.whatsfordinner.models.MealPlan;
import com.example.shehbashahab.whatsfordinner.models.Recipe;
import com.example.shehbashahab.whatsfordinner.models.ScheduleableMeal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database Info
    private static final String DATABASE_NAME = "dinnerDatabase";
    private static final int DATABASE_VERSION = 6;

    // Table Names
    private static final String TABLE_RECIPES = "recipes";
    private static final String TABLE_INGREDIENTS = "ingredients";
    private static final String TABLE_GROCERIES = "groceries";
    private static final String TABLE_SCHEDULEABLE_MEALS = "scheduleable_meals";
    private static final String TABLE_MEAL_PLANS = "meal_plan";

    // Recipe Table Columns
    private static final String KEY_RECIPES_ID = "id";
    private static final String KEY_RECIPE_NAME = "name";
    private static final String KEY_RECIPE_PICTURE_PATH = "picture";
    private static final String KEY_RECIPE_DIRECTIONS = "directions";
    private static final String KEY_RECIPE_INGREDIENTS = "ingredients";

    // Ingredient Table Columns
    private static final String KEY_INGREDIENTS_ID = "id";
    private static final String KEY_INGREDIENT_NAME = "name";
    private static final String KEY_INGREDIENT_UNIT = "unit";

    // Grocery Table Columns
    private static final String KEY_GROCERIES_ID = "id";
    private static final String KEY_GROCERY_NAME = "grocery";
    private static final String KEY_GROCERY_UNIT = "unit";
    private static final String KEY_GROCERY_COUNT = "count";

    // Scheduleable Meal Columns
    private static final String KEY_SCHEDULEABLE_MEAL_ID = "id";
    private static final String KEY_SCHEDULEABLE_MEAL_NAME = "name";

    //  Meal Plan Columns
    private static final String KEY_MEAL_PLAN_ID = "id";
    private static final String KEY_MEAL_PLAN_DAY = "day";
    private static final String KEY_MEAL_BREAKFAST = "breakfast";
    private static final String KEY_MEAL_LUNCH = "lunch";
    private static final String KEY_MEAL_DINNER = "dinner";


    private static final String KEY_MEAL_FATS = "fats";
    private static final String KEY_MEAL_CARB = "carb";
    private static final String KEY_MEAL_Proiens = "proteins";


    private static final String TAG = DatabaseHelper.class.getName();
    private static DatabaseHelper sInstance;


    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (sInstance == null) {
            sInstance = new DatabaseHelper(context.getApplicationContext());
        }
        return sInstance;
    }

    // Called when the database connection is being configured.
    // Configure database settings for things like foreign key support, write-ahead logging, etc.
    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_RECIPES_TABLE = "CREATE TABLE " + TABLE_RECIPES +
                "(" +
                KEY_RECIPES_ID + " INTEGER PRIMARY KEY," +
                KEY_RECIPE_NAME + " TEXT," +
                KEY_RECIPE_DIRECTIONS + " TEXT," +
                KEY_RECIPE_PICTURE_PATH + " TEXT," +
                KEY_RECIPE_INGREDIENTS + " TEXT," +
                KEY_MEAL_CARB + "FLOAT "+
                KEY_MEAL_FATS + "FLOAT"+
                KEY_MEAL_Proiens + "FLOAT"+
                ")";

        String CREATE_INGREDIENTS_TABLE = "CREATE TABLE " + TABLE_INGREDIENTS +
                "(" +
                KEY_INGREDIENTS_ID + " INTEGER PRIMARY KEY," +
                KEY_INGREDIENT_NAME + " TEXT," +
                KEY_INGREDIENT_UNIT + " TEXT" +
                ")";

        String CREATE_GROCERIES_TABLE = "CREATE TABLE " + TABLE_GROCERIES +
                "(" +
                KEY_GROCERIES_ID + " INTEGER PRIMARY KEY," +
                KEY_GROCERY_NAME + " TEXT," +
                KEY_GROCERY_UNIT + " TEXT," +
               KEY_GROCERY_COUNT + " INTEGER" +
                ")";
        String CREATE_SCHEDULEABLE_MEALS_TABLE = "CREATE TABLE " + TABLE_SCHEDULEABLE_MEALS +
                "(" +
                KEY_SCHEDULEABLE_MEAL_ID + " INTEGER PRIMARY KEY," +
                KEY_SCHEDULEABLE_MEAL_NAME + " TEXT" +
                ")";

        String CREATE_MEAL_PLANS_TABLE = "CREATE TABLE " + TABLE_MEAL_PLANS +
                "(" +
                KEY_MEAL_PLAN_ID + " INTEGER PRIMARY KEY," +
                KEY_MEAL_BREAKFAST + " TEXT," +
                KEY_MEAL_LUNCH + " TEXT," +
                KEY_MEAL_DINNER + " TEXT," +
                KEY_MEAL_PLAN_DAY + " INT" +
                ")";

        db.execSQL(CREATE_RECIPES_TABLE);
        db.execSQL(CREATE_INGREDIENTS_TABLE);
        db.execSQL(CREATE_GROCERIES_TABLE);
        db.execSQL(CREATE_SCHEDULEABLE_MEALS_TABLE);
        db.execSQL(CREATE_MEAL_PLANS_TABLE);
    }

    // Called when the database needs to be upgraded.
    // This method will only be called if a database already exists on disk with the same DATABASE_NAME,
    // but the DATABASE_VERSION is different than the version of the database that exists on disk.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion != newVersion) {
            // Simplest implementation is to drop all old tables and recreate them
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_RECIPES);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_INGREDIENTS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_GROCERIES);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCHEDULEABLE_MEALS);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_MEAL_PLANS);
            onCreate(db);
        }
    }

    // ADD METHODS

    public void addRecipe(Recipe recipe) {

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put(KEY_RECIPE_NAME, recipe.getName());
            values.put(KEY_RECIPE_DIRECTIONS, recipe.getDirections());
            //values.put(KEY_MEAL_CARB,recipe.getCarbs());
            values.put(KEY_RECIPE_INGREDIENTS, recipe.getIngredients());
            values.put(KEY_RECIPE_PICTURE_PATH, recipe.getPicturePath());
            //values.put(KEY_MEAL_FATS,recipe.getFats());
            //values.put(KEY_MEAL_Proiens,recipe.getProtiens());
            db.insertOrThrow(TABLE_RECIPES, null, values);
            db.setTransactionSuccessful();

        } catch (Exception e) {
            Log.d(TAG, "Error while trying to add recipe to database");
            String error = e.getMessage().toString();
            error+="00";
        } finally {
            db.endTransaction();
        }
    }

    public void addGrocery(Grocery grocery) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put(KEY_GROCERY_NAME, grocery.getName());
            values.put(KEY_GROCERY_UNIT, grocery.getUnit());
            db.insertOrThrow(TABLE_GROCERIES, null, values);
            db.setTransactionSuccessful();

        } catch (Exception e) {
            Log.d(TAG, "Error while trying to add grocery to database");
            String error = e.getMessage().toString();
        } finally {
            db.endTransaction();
        }
    }

    public void newGroceriesList(ArrayList<Grocery> newList){

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            //db.delete(TABLE_GROCERIES ,null,null);
            //db.execSQL("delete from groceries");
            db.execSQL("delete from groceries");

            for(int i=0;i<newList.size();i++){
                addGrocery(newList.get(i));
            }
        }catch (Exception ex){
            String errorCaught = ex.getMessage().toString();
        }
        db.endTransaction();
        db.close();
    }

    public void addIngredient(Ingredient ingredient) {

        SQLiteDatabase db = getWritableDatabase();

        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put(KEY_INGREDIENT_NAME, ingredient.getName());
            values.put(KEY_INGREDIENT_UNIT, ingredient.getUnit());
            db.insertOrThrow(TABLE_INGREDIENTS, null, values);
            db.setTransactionSuccessful();

        } catch (Exception e) {
            Log.d(TAG, "Error while trying to add ingredient to database");
        } finally {
            db.endTransaction();
        }
    }

    public void addScheduleableMeal(ScheduleableMeal meal) {

        SQLiteDatabase db = getWritableDatabase();

        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put(KEY_SCHEDULEABLE_MEAL_NAME, meal.getName());
            db.insertOrThrow(TABLE_SCHEDULEABLE_MEALS, null, values);
            db.setTransactionSuccessful();

        } catch (Exception e) {
            Log.d(TAG, "Error while trying to add scheduleable meal to database");
        } finally {
            db.endTransaction();
        }
    }

    public void addMealPlan(MealPlan mealPlan) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues values = new ContentValues();
            values.put(KEY_MEAL_PLAN_DAY, mealPlan.getDay());
            values.put(KEY_MEAL_BREAKFAST, mealPlan.getBreakfast());
            values.put(KEY_MEAL_LUNCH, mealPlan.getLunch());
            values.put(KEY_MEAL_DINNER, mealPlan.getDinner());
            db.insertOrThrow(TABLE_MEAL_PLANS, null, values);
            db.setTransactionSuccessful();

        } catch (Exception e) {
            Log.d(TAG, "Error while trying to add meal plan to database");
        } finally {
            db.endTransaction();
        }
    }

    // UPDATE METHODS

    public int updateRecipe(Recipe originalRecipe, Recipe updatedRecipe) {

        SQLiteDatabase db = getWritableDatabase();

        // Get reference to original
        int recipeID = getRecipeIdByName(originalRecipe.getName());

        ContentValues values = new ContentValues();
        values.put(KEY_RECIPE_NAME, updatedRecipe.getName());
        values.put(KEY_RECIPE_DIRECTIONS, updatedRecipe.getDirections());
        values.put(KEY_RECIPE_PICTURE_PATH, updatedRecipe.getPicturePath());
        values.put(KEY_RECIPE_INGREDIENTS, updatedRecipe.getIngredients());

        return db.update(TABLE_RECIPES, values, KEY_RECIPES_ID + " = ?",
                new String[]{String.valueOf(recipeID)});
    }

    public int updateGroceryCount(Grocery grocery, int count) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_GROCERY_COUNT, count);


        return db.update(TABLE_GROCERIES, values, KEY_GROCERY_NAME + " = ?",
                new String[]{String.valueOf(grocery.getName())});
    }

    // QUERY METHODS

    public Recipe getRecipeByName(String recipeName) {
        Recipe recipe = null;
        String RECIPES_SELECT_QUERY =
                "SELECT * FROM " + TABLE_RECIPES + " WHERE " + KEY_RECIPE_NAME + " = '" + recipeName.trim() + "' COLLATE NOCASE";
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(RECIPES_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    recipe = new Recipe(cursor.getString(cursor.getColumnIndex(KEY_RECIPE_NAME)), cursor.getString(cursor.getColumnIndex(KEY_RECIPE_DIRECTIONS)), cursor.getString(cursor.getColumnIndex(KEY_RECIPE_PICTURE_PATH)), cursor.getString(cursor.getColumnIndex(KEY_RECIPE_INGREDIENTS)), cursor.getFloat(cursor.getColumnIndex(KEY_MEAL_CARB)),cursor.getFloat(cursor.getColumnIndex(KEY_MEAL_FATS)),cursor.getFloat(cursor.getColumnIndex(KEY_MEAL_Proiens)));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get recipes from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return recipe;
    }

    public int getRecipeIdByName(String recipeName) {
        int id = 0;
        String RECIPES_SELECT_QUERY =
                "SELECT * FROM " + TABLE_RECIPES + " WHERE " + KEY_RECIPE_NAME + " = '" + recipeName.trim() + "' COLLATE NOCASE";
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(RECIPES_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    id = cursor.getInt(cursor.getColumnIndex(KEY_RECIPES_ID));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get recipes from database by id");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return id;
    }

    public Ingredient getIngredientByName(String ingredientName) {
        Ingredient ingredient = null;
        String RECIPES_SELECT_QUERY =
                "SELECT * FROM " + TABLE_INGREDIENTS + " WHERE " + KEY_INGREDIENT_NAME + " = '" + ingredientName.trim() + "' COLLATE NOCASE";
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(RECIPES_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    ingredient = new Ingredient(cursor.getString(cursor.getColumnIndex(KEY_INGREDIENT_NAME)), cursor.getString(cursor.getColumnIndex(KEY_INGREDIENT_UNIT)));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get ingredients from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return ingredient;
    }

    public Grocery getGroceriesByName(String groName) {
        String error="";
        Grocery go = null;
        String GRO_SELECT_QUERY =
                "SELECT * FROM " + TABLE_GROCERIES + " WHERE " + KEY_GROCERY_NAME + " = '" + groName.trim() + "' COLLATE NOCASE";
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(GRO_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    int id = Integer.parseInt(cursor.getString(cursor.getColumnIndex(KEY_GROCERIES_ID)));
                    String name = cursor.getString(cursor.getColumnIndex(KEY_GROCERY_NAME));
                    String unit = cursor.getString(cursor.getColumnIndex(KEY_GROCERY_UNIT));
                    int count = cursor.getInt(cursor.getColumnIndex(KEY_GROCERY_COUNT));
                    go = new Grocery(name,unit,count);
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get ingredients from database");
             error = e.getMessage().toString();
        }
        finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return go;
    }

    public List<String> getAllIngredientLabels() {
        List<String> ingredients = new ArrayList<>();

        String INGREDIENTS_SELECT_QUERY =
                "SELECT * FROM " + TABLE_INGREDIENTS;
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(INGREDIENTS_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    ingredients.add(cursor.getString(cursor.getColumnIndex(KEY_INGREDIENT_NAME)));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get all ingredients from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return ingredients;
    }

    public List<Grocery> getAllGroceries() {

        List<Grocery> groceries = new ArrayList<>();

       // String GROCERIES_SELECT_QUERY = "SELECT * FROM " + TABLE_GROCERIES+" where count = 1 ";
        String GROCERIES_SELECT_QUERY = "SELECT * FROM " + TABLE_GROCERIES;
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(GROCERIES_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    String name = cursor.getString(cursor.getColumnIndex(KEY_GROCERY_NAME));
                    String unit = cursor.getString(cursor.getColumnIndex(KEY_GROCERY_UNIT));
                    int count = cursor.getInt(cursor.getColumnIndex(KEY_GROCERY_COUNT));

                    Grocery grocery = new Grocery(name, unit, count);
                    groceries.add(grocery);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get all groceries from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }

        for(int i=0;i<groceries.size();i++){
            if(groceries.get(i).count == -1){
                groceries.remove(i);
            }
        }
        return groceries;
    }

    public List<Recipe> getAllRecipes() {

        List<Recipe> recipes = new ArrayList<>();

        String RECIPES_SELECT_QUERY =
                "SELECT * FROM " + TABLE_RECIPES;

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(RECIPES_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    String name = cursor.getString(cursor.getColumnIndex(KEY_RECIPE_NAME));
                    String picturePath = cursor.getString(cursor.getColumnIndex(KEY_RECIPE_PICTURE_PATH));
                    String directions = cursor.getString(cursor.getColumnIndex(KEY_RECIPE_DIRECTIONS));
                    String ingredients = cursor.getString(cursor.getColumnIndex(KEY_RECIPE_INGREDIENTS));
                    float c = cursor.getFloat(cursor.getColumnIndex(KEY_RECIPE_INGREDIENTS));
                    float f = cursor.getFloat(cursor.getColumnIndex(KEY_RECIPE_INGREDIENTS));
                    float p = cursor.getFloat(cursor.getColumnIndex(KEY_RECIPE_INGREDIENTS));

                    Recipe recipe = new Recipe(name, directions, picturePath, ingredients,c,f,p);
                    recipes.add(recipe);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get all groceries from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return recipes;
    }

    public List<String> getAllRecipesLabels() {

        List<Recipe> recipes = new ArrayList<>();
        List<String> meals = new ArrayList<>();


        String RECIPES_SELECT_QUERY =
                "SELECT * FROM " + TABLE_RECIPES;

        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(RECIPES_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    String name = cursor.getString(cursor.getColumnIndex(KEY_RECIPE_NAME));
                    String picturePath = cursor.getString(cursor.getColumnIndex(KEY_RECIPE_PICTURE_PATH));
                    String directions = cursor.getString(cursor.getColumnIndex(KEY_RECIPE_DIRECTIONS));
                    String ingredients = cursor.getString(cursor.getColumnIndex(KEY_RECIPE_INGREDIENTS));
                    float c = cursor.getFloat(cursor.getColumnIndex(KEY_RECIPE_INGREDIENTS));
                    float f = cursor.getFloat(cursor.getColumnIndex(KEY_RECIPE_INGREDIENTS));
                    float p = cursor.getFloat(cursor.getColumnIndex(KEY_RECIPE_INGREDIENTS));

                    Recipe recipe = new Recipe(name, directions, picturePath, ingredients,c,f,p);
                    recipes.add(recipe);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get all groceries from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }

        for (int j = 0; j <recipes.size();j++)
            meals.add(recipes.get(j).getName());
        return meals;
    }
    public List<String> getMealPlanes() {
        List<String> meals = new ArrayList<>();

        String MEALS_SELECT_QUERY =
                "SELECT * FROM " + TABLE_SCHEDULEABLE_MEALS;
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(MEALS_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    meals.add(cursor.getString(cursor.getColumnIndex(KEY_SCHEDULEABLE_MEAL_NAME)));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get all scheduleable meals from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return meals;
    }

    public List<String> getAllScheduleableMealLabels() {
        List<String> meals = new ArrayList<>();

        String MEALS_SELECT_QUERY =
                "SELECT * FROM " + TABLE_SCHEDULEABLE_MEALS;
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(MEALS_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    meals.add(cursor.getString(cursor.getColumnIndex(KEY_SCHEDULEABLE_MEAL_NAME)));
                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get all scheduleable meals from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return meals;
    }

    public int countScheduleableMealsMatchingName(String name) {
        int count = 0;

        String RECIPES_SELECT_QUERY =
                "SELECT count(*) FROM " + TABLE_SCHEDULEABLE_MEALS + " WHERE " + KEY_SCHEDULEABLE_MEAL_NAME + " LIKE '" + name + "%' COLLATE NOCASE";
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(RECIPES_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                count = cursor.getInt(0);
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get matching schedule meal count");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }

        return count;
    }

    public MealPlan getMealPlanByDay(int day) {
        MealPlan mealPlan = null;
        String RECIPES_SELECT_QUERY =
                "SELECT * FROM " + TABLE_MEAL_PLANS + " WHERE " + KEY_MEAL_PLAN_DAY + " = '" + day + "'";
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(RECIPES_SELECT_QUERY, null);
        try {
            if (cursor.moveToFirst()) {
                do {
                    String breakfast = cursor.getString(cursor.getColumnIndex(KEY_MEAL_BREAKFAST));
                    String lunch = cursor.getString(cursor.getColumnIndex(KEY_MEAL_LUNCH));
                    String dinner = cursor.getString(cursor.getColumnIndex(KEY_MEAL_DINNER));
                    mealPlan = new MealPlan(day, breakfast, lunch, dinner);

                } while (cursor.moveToNext());
            }
        } catch (Exception e) {
            Log.d(TAG, "Error while trying to get ingredients from database");
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
        return mealPlan;
    }

    // DELETE METHODS

    public int deleteUsedScheduleableMeal(String name) {
        SQLiteDatabase db = getWritableDatabase();

        return db.delete(TABLE_SCHEDULEABLE_MEALS, KEY_SCHEDULEABLE_MEAL_NAME + " = ?",
                new String[]{String.valueOf(name)});
    }
}