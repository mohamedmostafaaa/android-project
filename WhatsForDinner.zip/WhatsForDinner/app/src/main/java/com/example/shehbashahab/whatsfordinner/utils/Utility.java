package com.example.shehbashahab.whatsfordinner.utils;

import java.io.File;

/**
 * Created by shehba.shahab on 10/6/17.
 */

public class Utility {

    public static boolean isLocalFile(String path) {
        return new File(path).exists();
    }
}
